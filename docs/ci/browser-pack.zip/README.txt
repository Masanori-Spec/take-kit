TakeKit sample pack
Keep instrument.sfz beside samples/. One MIDI key, sequential round robin. Extract the ZIP before loading the SFZ. SFZ player compatibility has not been verified.
Boundaries are integer frames [start,end). See manifest.json for source SHA-256, order, explicit fades and shared gain.
Use only recordings you have the right to use.
